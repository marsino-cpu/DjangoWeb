from contacts.models import Astronaut
from django import forms


class AstronautForm(forms.ModelForm):
    class Meta:
        model = Astronaut
        fields = ['first_name', 'last_name', 'gender']
