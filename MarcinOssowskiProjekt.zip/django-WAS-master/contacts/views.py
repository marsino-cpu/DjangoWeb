from django.http import HttpResponseRedirect
from django.urls import reverse
from django.views.generic import TemplateView, View
from contacts.forms import AstronautForm
from contacts.models import Astronaut


class ContactView(TemplateView):
    template_name = 'contacts/view.html'

    def get_context_data(self, **kwargs):
        return {
            'contacts': Astronaut.objects.all()
        }


class ContactAddForm(TemplateView):
    template_name = 'contacts/form.html'

    def get_context_data(self, **kwargs):
        form = AstronautForm()
        return locals()


class ContactAddFail(TemplateView):
    template_name = 'contacts/fail.html'


class ContactAddSuccess(TemplateView):
    template_name = 'contacts/success.html'


class ContactAddView(View):
    def get(self, request):
        return HttpResponseRedirect(reverse('contact-add-fail'))

    def post(self, request):
        form = AstronautForm(request.POST)

        if not form.is_valid():
            return HttpResponseRedirect(reverse('contact-add-fail'))

        Astronaut.objects.create(
            first_name=form.cleaned_data.get('first_name'),
            last_name=form.cleaned_data.get('last_name'),
            date_of_birth=form.cleaned_data.get('date_of_birth')
        )

        return HttpResponseRedirect(reverse('contact-add-success'))
